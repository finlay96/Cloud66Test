
TEXT = input("Type the main text you wish to use ")
#TEXT = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we'll all have tea"
SUBTEXT = input("Type the subtext you wish to compare against the text here ")
#SUBTEXT = "Polx"

def matchingPositions(string, charactersToBeFound):
    pos = set() #to ensure multiple of the same values don't get added
    check = False #initialise check to false
    for i in range(0, len(string)): #looking through each character in the string
        if string[i] == charactersToBeFound[0]: #if the character of the string matches the first character of the sub text
            if len(charactersToBeFound) == 1: #if there's only one character being looked for skip the iterating through character set stage
                check = True
            else:
                #iterate through the desired character set, if at any point it doesn't match then then break the loop
                for j in range(1, len(charactersToBeFound)):
                    if string[i+j] == charactersToBeFound[j]:
                        check = True
                    else: #if any characters don't match then set check to false and break the loop
                        check = False
                        break

            if check == True:
                pos.add(i+1) #add the position of the first matched letter to the set

    return pos

ans = matchingPositions(TEXT.lower(), SUBTEXT.lower()) #call the match positions function, but use lower case of both variables

if ans == set(): #if the answer is an ampty set
    print("<no matches>")
else:
    print(sorted(ans)) #sort the set so it is easier to read for the user
